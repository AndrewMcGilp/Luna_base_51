#Luna Base 51 by Andrew McGilp
#A Python Pi 
import pygame, math, sys, random
from pygame.locals import *

pygame.init()

SCREEN_WIDTH = 800
#SCREEN_HEIGHT = 600#for normal screen
SCREEN_HEIGHT = 480#for smal screen 

#Color    R    G    B
WHITE  = (255, 255, 255)
GREEN  = (0, 255, 0)
RED    = (255, 0 ,0)
BLUE   = (  0,   0, 255)
YELLOW = (255, 255, 0)

LEFT = 1
MIDDLE = 2
RIGHT = 3
UP = 4
DOWN = 5
MENU_NO = 0
ASTEROID_TYPE = 1

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), DOUBLEBUF, 16)# plays better in full screen mode
#screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), FULLSCREEN, 16)
pygame.display.set_caption('Luna Base 51')
clock = pygame.time.Clock()
pygame.mouse.set_visible(False)

#----------Load sprites images sound and fonts----------
#Load Font's
myHudFont = pygame.font.SysFont("none", 28)
myMsgFont = pygame.font.SysFont("none", 92)

strMsg = myMsgFont.render('Update ME!', True, GREEN)

#Load image's
bgImg = pygame.image.load('Stars_Earth1.png').convert()
startImg = pygame.image.load('GameStart.png').convert_alpha()
baseImg = pygame.image.load('MoonBase4.png').convert_alpha()
coverImg = pygame.image.load('MtlPlate2.png').convert_alpha()
laserImg = pygame.image.load('Laser.png').convert_alpha()
asteroidImg = pygame.image.load('Asteroid3.png').convert_alpha()
expoldImg = pygame.image.load('Explod5.png').convert_alpha()
damageImg = pygame.image.load('Damage3.png').convert_alpha()
playerImg = pygame.image.load('player4.png').convert_alpha()
ufoImg = pygame.image.load('UFO4.png').convert_alpha()
missileImg = pygame.image.load('Bomb2.png').convert_alpha()

#Load Sounds
pygame.mixer.pre_init(44100,16, 2, 4096)
laserSnd = pygame.mixer.Sound('laser.wav')
laserSnd.set_volume(0.6)
explodSnd = pygame.mixer.Sound('explos.wav')
explodSnd.set_volume(0.5)

done = False
playSound = False
showMsg = False
fullScreen = False
pauseGame = False

#Player Position
posX = SCREEN_WIDTH / 2 
posY = SCREEN_HEIGHT - 20
#Mouse Pos
posx = 0
posy = 0

hiScore = 0
score = 0
asteroidQty = 0
distroidQty = 0
levelNo = 0
health = 0
oldHealth = 0
dropX = 340
explodSize = 2
rank = 0
rndRangeY = -400

# The player sprite
player_list = pygame.sprite.Group()
screen_rect = screen.get_rect()
class Player(pygame.sprite.Sprite):
    
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        super().__init__()
        self.myTexture1 = playerImg
        self.position = (posX, posY)
        self.speed = self.direction = 0
        self.k_left = self.k_right = 0
        
    def update(self):
        
        self.speed = 0
        self.direction = ((400 - posx) * 0.2)
        x, y = self.position
        rad = self.direction * math.pi / 180
        x += - self.speed*math.sin(rad)
        y += -self.speed*math.cos(rad)
        self.position = (x, y)
        self.image = pygame.transform.rotate(self.myTexture1, self.direction)
        self.rect = self.image.get_rect()
        self.rect.center = self.position
               
player = Player()
player_list.add(player)

# The laser sprite
laser_list = pygame.sprite.Group()
class Laser(pygame.sprite.Sprite):
 
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        super().__init__()
        self.myTexture1 = laserImg
        self.position = (posX, posY)# player position
        self.speed = 40
        self.direction = Direction
        self.image = pygame.transform.rotate(self.myTexture1, self.direction)
        self.rect = self.image.get_rect()
        
    def update(self):
        x, y = self.position
        rad = self.direction * math.pi / 180
        x += - self.speed*math.sin(rad)
        y += -self.speed*math.cos(rad)
        self.position = (x, y)
        self.image = pygame.transform.rotate(self.myTexture1, self.direction)
        self.rect = self.image.get_rect()
        self.rect.center = self.position
        self.speed = 5
        
#The asteroid stuff
asteroid_list = pygame.sprite.Group()
class Asteroid(pygame.sprite.Sprite):
    
    def __init__(self):
        super().__init__()
        self.myTexture1 = asteroidImg
        self.image = self.myTexture1
        self.rect = pygame.Rect(self.myTexture1.get_rect())
        #self.rect = pygame.Rect(40, 40, 0)
        self.type = ASTEROID_TYPE
        
    def update(self):
        if self.type == 0:
            self.rect.y += (3 + rank)
        else:
            self.rect.y += 1

#Create Ufo's aka Mothership or UFO's
ufo_list = pygame.sprite.Group()
class Ufo(pygame.sprite.Sprite):
    
    def __init__(self):
        super().__init__()
        self.myTexture1 = ufoImg
        self.image = self.myTexture1
        self.rect = pygame.Rect(self.myTexture1.get_rect())
        self.health = 100
        self.speed = 1
        
        
    def update(self):
        if showMsg == False:
            self.rect.x += self.speed
            if self.rect.x == dropX:
                self.speed = 5

            
#Explosion  effect     
explod_list = pygame.sprite.Group()       
class Explod(pygame.sprite.Sprite):
    
    def __init__(self):
        super().__init__()
        self.myTexture1 = expoldImg
        self.image = self.myTexture1
        self.rect = pygame.Rect(self.myTexture1.get_rect())
        self.timer = 0
        self.size = 2
        
    def update(self):
        self.rect.y -= self.size * 0.5
        self.rect.x -= self.size * 0.5
        self.scaler += self.size
        self.image = pygame.transform.scale(self.myTexture1, (self.scaler , self.scaler)) 
        self.timer += 1
        
#Create Damage        
damage_list = pygame.sprite.Group()
class Damage(pygame.sprite.Sprite):
    
    def __init__(self):
        super().__init__()
        self.myTexture1 = damageImg
        self.image = self.myTexture1
        self.rect = pygame.Rect(self.myTexture1.get_rect())

def CreateLaser():#Fire the laser
    laser = Laser()
    laser_list.add(laser)
    laser.rect.x = posX
    laser.rect.y = posY
    if playSound:
        channel = laserSnd.play() 
def CreateAsteroid():#Missile
    asteroid = Asteroid()
    asteroid.image = missileImg
    asteroid.rect.x = dropX
    asteroid.rect.y = 30
    asteroid.type = 0
    asteroid_list.add(asteroid)
    
def CreateAsteroids():
    for i in range(asteroidQty):
        asteroid = Asteroid()
        asteroid.image = asteroidImg
        asteroid.rect.x = random.randrange(10, 740)
        asteroid.rect.y = random.randrange(rndRangeY, -200)
        asteroid.type = 1
        asteroid_list.add(asteroid)


#Create explotion effect   
def CreateExplod():
    explod = Explod()
    explod.scaler = 30 * explodSize
    explod.size = explodSize 
    explod.rect.x = explodPosX
    explod.rect.y = explodPosY
    explod_list.add(explod)
    if playSound:
        channel = explodSnd.play()
        
#Create damage
def CreateDamage():
    damage = Damage()
    damage.rect.x = explodPosX
    damage.rect.y = explodPosY  
    damage_list.add(damage)
    
#Create UFO
def CreateUfo():
    ufo = Ufo()
    ufo.rect.x = -150
    ufo.rect.y = 30
    ufo.speed = 2
    ufo_list.add(ufo)


            
while not done:
#____________________The Main game loop___________________
    #Handel input **Mouse** or **RAT**
    for event in pygame.event.get():
        
        pos = pygame.mouse.get_pos()
        posx = pos[0]
        posy = pos[1]
        
        if event.type == pygame.QUIT:
            done = True
            
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == LEFT:
                if MENU_NO == 0:
                    if health > 0:
                        if pauseGame == False:
                            CreateLaser()
                        pauseGame = False
                        showMsg = False
                    else:
                        if levelNo > 0:
                            levelNo = 0
                        else:
                            asteroidQty = 20
                            distroidQty = asteroidQty
                            health = 100
                            oldHealth = 0
                            score = 0
                            rank = 0
                            rndRangeY -400
                            for damage in damage_list:
                                damage_list.remove(damage)
                            for laser in laser_list:
                                laser_list.remove(laser)
                                
                elif MENU_NO == 1:
                    if fullScreen:
                        fullScreen = False
                        screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), DOUBLEBUF, 16) 
                    else:
                        fullScreen = True
                        screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), FULLSCREEN, 16)
                elif MENU_NO == 2:
                    if playSound:
                        playSound = False
                    else:
                        playSound = True
                elif MENU_NO == 3:
                    done = True
                    
            elif event.button == RIGHT:
                if levelNo > 0:
                    if pauseGame == False and health > 0:
                        pauseGame = True
                        strMsg = myMsgFont.render('   PAUSED!', True, GREEN)
                    else:
                        pauseGame = False
                        health = 0
                        levelNo = 0
                        
                else:
                    done = True

            elif event.button == UP and levelNo == 0:
                if MENU_NO < 3:
                    MENU_NO += 1
                else:
                    MENU_NO = 0
            elif event.button == DOWN and levelNo == 0:
                if MENU_NO > 0:
                    MENU_NO -= 1
                else:
                    MENU_NO = 3     
#Game Logik
    #check for collitions
    for laser in laser_list:
            
        asteroid_hit_list = pygame.sprite.spritecollide(laser, asteroid_list, False)  
            
        for asteroid in asteroid_hit_list:
            asteroid_list.remove(asteroid)
            laser_list.remove(laser)
            if asteroid.type == 0:
                explodPosX = asteroid.rect.x - 40
                explodPosY = asteroid.rect.y - 40
                score += 50 * rank
                explodSize = 4
            else:
                explodPosX = asteroid.rect.x - 5
                explodPosY = asteroid.rect.y - 1
                explodSize = 2
                score += 1
                distroidQty += 1
            CreateExplod()
             
        ufo_hit_list = pygame.sprite.spritecollide(laser, ufo_list, False)   
        for ufo in ufo_hit_list:
            ufo.speed = 5
            explodPosX = laser.rect.x
            explodPosY = laser.rect.y - 20
            explodSize = 1
            CreateExplod()
            laser_list.remove(laser)
            score += 10
            dropX = ufo.rect.x + 80
            CreateAsteroid()
   
        if laser.rect.y < -10 or laser.rect.y > SCREEN_HEIGHT + 10:
            laser_list.remove(laser)
            
        if laser.rect.x < -10 or laser.rect.x > SCREEN_WIDTH + 10:
            laser_list.remove(laser)
      
    for asteroid in asteroid_list:
        
        if asteroid.rect.y > -50:
            showMsg = False
        if asteroid.rect.y > SCREEN_HEIGHT -50:

            if asteroid.type == 0:
                explodPosX = asteroid.rect.x - 100
                explodPosY = asteroid.rect.y - 80
                explodSize = 8
            else:
                explodPosX = asteroid.rect.x - 5
                explodPosY = asteroid.rect.y - 1
                explodSize = 2
                distroidQty += 1
            CreateExplod()
            CreateDamage()
            asteroid_list.remove(asteroid)

            if health > 0:
                if asteroid.type == 0:
                    health = 0
                else:
                    health -= 10
        
    for player in player_list:
        Direction = player.direction
 
    for explod in explod_list:
        if explod.timer > 26:
            explod_list.remove(explod)
            
    for ufo in ufo_list:
        if ufo.rect.x > SCREEN_WIDTH + 50:
            ufo_list.remove(ufo)
            
    if hiScore < score:
        hiScore = score
        
    if health > 0:
        if distroidQty == asteroidQty:
            levelNo += 1
            asteroidQty += 10
            distroidQty = 0
            rndRangeY -= 40
            CreateAsteroids()
            strMsg = myMsgFont.render('GET READY!', True, GREEN)
            showMsg = True
            if health == oldHealth:
                rank += 1
                strMsg = myMsgFont.render('  PERFECT!', True, BLUE)
                CreateUfo()
            oldHealth = health
    else:        
        for asteroid in asteroid_list:
            asteroid_list.remove(asteroid)
        for ufo in ufo_list:
            ufo_list.remove(ufo)
            
        strMsg = myMsgFont.render('GAME OVER!', True, RED)
        showMsg = True
 
    #Update all the sprites if not paused
    if pauseGame == False:
        asteroid_list.update()
        laser_list.update()    
        player_list.update()
        explod_list.update()
        ufo_list.update()
    
#___________________RENDERING________________
    
    #screen.fill((0, 0, 0))
    screen.blit(bgImg, (0, 0))
    screen.blit(baseImg, (0, SCREEN_HEIGHT - 239))
    laser_list.draw(screen)
    player_list.draw(screen)
    screen.blit(coverImg, (338, SCREEN_HEIGHT - 28))
    damage_list.draw(screen)
    asteroid_list.draw(screen)
    ufo_list.draw(screen)
    explod_list.draw(screen)
   
    
    if levelNo > 0:        
        # String text for hud
        hudHealth = myHudFont.render('POWER : %s' % health, True, WHITE)#health
        hudLevel = myHudFont.render('LEVEL : %s' % levelNo, True, WHITE)#Level
        hudHiScore = myHudFont.render('HI-SCORE : %s' % hiScore, True, WHITE)#hi score
        hudScore = myHudFont.render('SCORE : %s' % score, True, WHITE)#score
        hudRank = myHudFont.render('RANK : %s' % rank, True, WHITE)#ranking
        #Draw the HUD
        screen.blit(hudScore, (20, 10))
        screen.blit(hudHiScore, (220, 10))
        screen.blit(hudHealth, (440, 10))
        screen.blit(hudLevel, (580, 10))
        screen.blit(hudRank, (690, 10))
        if showMsg == True or pauseGame == True:
            screen.blit(strMsg, (200, 200))            
    else:       
        if MENU_NO == 0:   
            strMsg1 = myHudFont.render('START GAME :', True, WHITE)#
        if MENU_NO == 1:
            if fullScreen:
                 strMsg1 = myHudFont.render('FULL SCREEN OFF :', True, GREEN)#
            else:
                strMsg1 = myHudFont.render('FULL SCREEN ON :', True, YELLOW)#
        if MENU_NO == 2:
            if playSound == True:
                strMsg1 = myHudFont.render('SOUND OFF :', True, GREEN)#
            else:
                strMsg1 = myHudFont.render('SOUND ON :', True, YELLOW)#
        if MENU_NO == 3:   
            strMsg1 = myHudFont.render('QUIT GAME :', True, RED)#
        if MENU_NO == 4:   
            strMsg1 = myHudFont.render('Menu No : %s' % MENU_NO, True, WHITE)#
            
        screen.blit(strMsg1, (290, 390))
        screen.blit(startImg, (100, 10))
               
    pygame.display.flip()
    clock.tick(30)
#__________________EXIT_THE_GAME____________         
pygame.quit()
sys.exit()    
#Things to do : Add a mother ship aka ufo friendly or not as a bonus
#Make asteroid rotate at random speeds and make them randomly differant
#Create a screen shot with hi score when the game is over
